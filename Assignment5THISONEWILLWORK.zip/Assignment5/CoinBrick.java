import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class CoinBrick extends Sprite
{
    boolean update()
    {
        return true;
    }
    
    void draw(Graphics g)
    {
        
    }

    @Override
    boolean isCoinBrick()
    {
        return true;
    }
}
